import librosa
import numpy as np
import joblib
import soundfile as sf
import os
from collections import Counter

# === 1. CONFIGURAÇÕES ===
# --- Configure aqui ---
CAMINHO_AUDIO_LONGO = r"C:\Users\Nicholas\OneDrive\Desktop\SONS\audio_bruto\output_gained_com_silencio.wav"  # <-- ALtere para o seu áudio longo
DURACAO_SEGMENTO_SEGUNDOS = 3  # Duração de cada segmento para análise (em segundos)
SR_ALVO = 22050  # Sample Rate alvo (DEVE ser o mesmo usado no treinamento do modelo!)
PASTA_SAIDA_RECORTES = "recortes_detectados"  # Nova pasta para indicar os refinamentos

# Configurações de sobreposição para a ANÁLISE INICIAL dos segmentos
OVERLAP_PERCENTAGE = 0.75  # 0.0 para sem sobreposição, 0.5 para 50% de sobreposição.
SALVAR_RECORTE_SILENCIO = True  # Altere para True se quiser salvar segmentos de Silêncio.

# Duração máxima para um evento detectado (eventos mais longos serão subdivididos na pós-processamento)
MAX_EVENT_DURATION_SECONDS = 6  # Eventos não podem ultrapassar esta duração.

# Classes (deve ser idêntico ao que você usou no treinamento)
NOMES_CLASSES = ["Silêncio", "Tosse", "Respiração", "Ronco", "Ruido"]

# Nova configuração: Resolução da linha do tempo para decidir o vencedor em sobreposições
# Um valor menor (ex: 0.1s) significa uma decisão mais granular, mas pode ser mais lento.
# Um valor maior (ex: 0.5s) é mais rápido, mas menos granular.
TIMELINE_RESOLUTION_SECONDS = 0.25


# --- Fim da Configuração ---


# === 2. FUNÇÃO DE EXTRAÇÃO DE FEATURES ===
def extract_audio_features(y, sr):
    """
    Extrai características de áudio (RMS, ZCR, Spectral Rolloff, Centroid, Bandwidth, Contrast, MFCCs e suas deltas).
    Retorna None se o segmento de áudio for muito curto ou se ocorrer um erro.
    """
    if len(y) < 512:  # Garante que há dados suficientes para FFT
        return None
    try:
        # n_fft precisa ser menor ou igual ao comprimento do sinal 'y'
        n_fft = min(2048, len(y))

        # Garante que as features são calculáveis mesmo para MFCCs
        if len(y) < n_fft:
            return None

        rms = librosa.feature.rms(y=y).mean()
        zcr = librosa.feature.zero_crossing_rate(y).mean()
        rolloff = librosa.feature.spectral_rolloff(y=y, sr=sr, n_fft=n_fft).mean()
        centroid = librosa.feature.spectral_centroid(y=y, sr=sr, n_fft=n_fft).mean()
        bandwidth = librosa.feature.spectral_bandwidth(y=y, sr=sr, n_fft=n_fft).mean()
        contrast = librosa.feature.spectral_contrast(y=y, sr=sr, n_fft=n_fft).mean()

        mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13, n_fft=n_fft)
        mfccs_mean = mfccs.mean(axis=1)
        mfccs_std = mfccs.std(axis=1)

        mfccs_delta = librosa.feature.delta(mfccs)
        mfccs_delta_mean = mfccs_delta.mean(axis=1)
        mfccs_delta_std = mfccs_delta.std(axis=1)

        mfccs_delta2 = librosa.feature.delta(mfccs, order=2)
        mfccs_delta2_mean = mfccs_delta2.mean(axis=1)
        mfccs_delta2_std = mfccs_delta2.std(axis=1)

        features = [rms, zcr, rolloff, centroid, bandwidth, contrast] + \
                   list(mfccs_mean) + \
                   list(mfccs_std) + \
                   list(mfccs_delta_mean) + \
                   list(mfccs_delta_std) + \
                   list(mfccs_delta2_mean) + \
                   list(mfccs_delta2_std)

        return features
    except Exception as e:
        # print(f"Erro na extração de features: {e}") # Descomente para depurar
        return None


# === NOVA FUNÇÃO: DETERMINAR VENCEDOR NA LINHA DO TEMPO ===
def determine_winning_classes_on_timeline(all_segment_results, total_audio_samples, sr, class_names,
                                          time_resolution_seconds):
    """
    Processa todos os resultados dos segmentos para criar uma linha do tempo não sobreposta,
    onde cada fatia de tempo é atribuída à classe com a maior soma de probabilidades dos segmentos que a cobrem.
    """
    time_resolution_samples = int(time_resolution_seconds * sr)
    if time_resolution_samples == 0:
        time_resolution_samples = sr  # fallback to 1 second if resolution too small for sr

    # Arredonda para cima para garantir que o áudio completo seja coberto
    num_time_slices = int(np.ceil(total_audio_samples / time_resolution_samples))

    # Inicializa um array 2D para acumular as probabilidades de cada classe em cada fatia de tempo
    # Linhas: fatias de tempo, Colunas: classes (Silêncio, Tosse, etc.)
    accumulated_probs_per_slice = np.zeros((num_time_slices, len(class_names)))

    # Preenche o accumulated_probs_per_slice com as probabilidades dos segmentos
    for segment_info in all_segment_results:
        # Calcula as fatias de tempo que este segmento cobre
        seg_start_slice = int(segment_info['start_sample'] / time_resolution_samples)
        seg_end_slice = int(
            (segment_info['end_sample'] - 1) / time_resolution_samples)  # -1 para incluir o último sample da fatia

        # Garante que os índices estejam dentro dos limites do array
        seg_start_slice = max(0, seg_start_slice)
        seg_end_slice = min(num_time_slices - 1, seg_end_slice)

        for i in range(seg_start_slice, seg_end_slice + 1):
            # Soma as probabilidades do segmento às probabilidades acumuladas da fatia de tempo
            accumulated_probs_per_slice[i] += segment_info['probabilities']

    final_events = []
    if num_time_slices == 0:
        return final_events  # Retorna vazio se não há fatias de tempo

    # Determina o vencedor para cada fatia de tempo e agrupa em eventos
    current_event_start_slice = 0
    current_event_id = -1  # Inicializa com um ID inválido ou "Silêncio"

    # Define o ID de "Silêncio" para usar como padrão se uma fatia não tiver cobertura
    silence_id = class_names.index("Silêncio") if "Silêncio" in class_names else 0

    # Determina o ID do primeiro evento
    if np.sum(accumulated_probs_per_slice[0]) > 0:
        current_event_id = np.argmax(accumulated_probs_per_slice[0])
    else:
        current_event_id = silence_id  # Padrão para Silêncio se não houver predição

    for i in range(1, num_time_slices):
        # Determina o ID do vencedor para a fatia de tempo atual
        winner_id_current_slice = silence_id  # Padrão
        if np.sum(accumulated_probs_per_slice[i]) > 0:
            winner_id_current_slice = np.argmax(accumulated_probs_per_slice[i])

        # Se a classe vencedora mudou, finaliza o evento atual e inicia um novo
        if winner_id_current_slice != current_event_id:
            event_start_sample = current_event_start_slice * time_resolution_samples
            event_end_sample = i * time_resolution_samples

            # Adiciona o evento somente se tiver duração positiva
            if event_end_sample > event_start_sample:
                final_events.append({
                    'start_sample': event_start_sample,
                    'end_sample': event_end_sample,
                    'prediction_id': current_event_id
                })
            current_event_start_slice = i
            current_event_id = winner_id_current_slice

    # Adiciona o último evento após o loop
    event_start_sample = current_event_start_slice * time_resolution_samples
    event_end_sample = total_audio_samples  # Garante que o último evento vai até o final do áudio
    if event_end_sample > event_start_sample:
        final_events.append({
            'start_sample': event_start_sample,
            'end_sample': event_end_sample,
            'prediction_id': current_event_id
        })

    return final_events


# === FUNÇÃO PARA SUBDIVIDIR EVENTOS MUITO LONGOS (Pós-processamento) ===
def enforce_max_event_duration(events, max_duration_samples):
    """
    Garante que nenhum evento exceda a duração máxima especificada, subdividindo-os se necessário.
    A classe do evento original é mantida para os sub-eventos.
    """
    enforced_events = []
    for event in events:
        event_duration_samples = event['end_sample'] - event['start_sample']

        if event_duration_samples > max_duration_samples:
            # Subdivide o evento longo em múltiplos eventos menores
            temp_start = event['start_sample']
            while temp_start < event['end_sample']:
                temp_end = min(temp_start + max_duration_samples, event['end_sample'])
                enforced_events.append({
                    'start_sample': temp_start,
                    'end_sample': temp_end,
                    'prediction_id': event['prediction_id']  # Mantém a classe original
                })
                temp_start = temp_end
        else:
            enforced_events.append(event)
    return enforced_events


# === 3. FUNÇÃO PRINCIPAL DE PREDIÇÃO E SEGMENTAÇÃO ===
def predict_and_segment(audio_path, model, scaler, sr_target, segment_duration_seconds,
                        overlap_percentage, output_folder, class_names, save_silent_segments,
                        max_event_duration_seconds, timeline_resolution_seconds):
    """
    Função principal que carrega um áudio, o segmenta em pequenas janelas, extrai features,
    coleta as probabilidades de predição, e então constrói uma linha do tempo única
    de eventos não sobrepostos baseada na maior probabilidade acumulada.
    Finalmente, salva os recortes resultantes.
    """
    # 3.1. Carregar o áudio longo
    try:
        y_long, sr_original = librosa.load(audio_path, sr=None)
        print(f"\n🎧 Carregando áudio: {os.path.basename(audio_path)}")
        print(f"Sample Rate original: {sr_original} Hz")
        print(f"Duração original: {len(y_long) / sr_original:.2f} segundos")
    except Exception as e:
        print(f"❌ ERRO ao carregar o áudio '{audio_path}': {e}")
        return

    # 3.2. Realizar Resample se necessário
    if sr_original != sr_target:
        print(f"🔁 Realizando resample de {sr_original} Hz para {sr_target} Hz...")
        y_long = librosa.resample(y_long, orig_sr=sr_original, target_sr=sr_target)
    sr = sr_target
    total_audio_samples = len(y_long)
    print(f"✅ Áudio processado com {total_audio_samples / sr:.2f} segundos (sample rate: {sr} Hz).")

    # 3.3. Preparar para segmentação e predição (com sobreposição)
    samples_per_segment = int(segment_duration_seconds * sr)
    hop_length = int(samples_per_segment * (1 - overlap_percentage))
    if hop_length == 0:
        hop_length = samples_per_segment // 2
        if hop_length == 0:
            hop_length = 1

    all_segment_results_with_probs = []

    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
        print(f"📁 Pasta de saída criada: '{output_folder}'")

    print(
        f"\n✨ Iniciando a classificação de segmentos (Duração: {segment_duration_seconds}s com {overlap_percentage * 100}% de sobreposição)...")

    # 3.4. Loop pelos segmentos (com sobreposição) para predição e coleta de probabilidades
    for start_sample in range(0, total_audio_samples - samples_per_segment + 1, hop_length):
        end_sample = start_sample + samples_per_segment
        segment_data = y_long[start_sample:end_sample]

        if len(segment_data) < samples_per_segment:
            continue

        features = extract_audio_features(segment_data, sr)

        if features is None:
            continue

        X_segment_scaled = scaler.transform([features])

        try:
            # É CRUCIAL que o modelo suporte predict_proba para esta abordagem!
            probabilities = model.predict_proba(X_segment_scaled)[0]
        except AttributeError:
            print("❌ ERRO: O modelo carregado não suporta 'predict_proba'. Esta refatoração exige isso.")
            print(
                "Por favor, garanta que seu 'modelo_xgb_sono_final.pkl' foi treinado com um modelo que implementa predict_proba (ex: XGBClassifier).")
            return

        all_segment_results_with_probs.append({
            'start_sample': start_sample,
            'end_sample': end_sample,
            'probabilities': probabilities  # Armazena todas as probabilidades
        })

    if not all_segment_results_with_probs:
        print("❌ Nenhuma predição foi gerada. O áudio pode ser muito curto ou inválido.")
        return

    # 3.5. CONSTRUÇÃO DA LINHA DO TEMPO ÚNICA (Decisão final por fatia de tempo)
    print(f"\n📊 Construindo linha do tempo única com resolução de {timeline_resolution_seconds}s...")
    final_non_overlapping_events = determine_winning_classes_on_timeline(
        all_segment_results_with_probs,
        total_audio_samples,
        sr,
        class_names,
        timeline_resolution_seconds
    )

    # 3.6. GARANTIR DURAÇÃO MÁXIMA DE EVENTOS
    print(f"\n📏 Enforcando duração máxima de {max_event_duration_seconds}s para eventos...")
    # Convert max_event_duration_seconds to samples for the function
    max_duration_samples = int(max_event_duration_seconds * sr)
    final_refined_events = enforce_max_event_duration(final_non_overlapping_events, max_duration_samples)

    # 3.7. Salvar os recortes finais e mostrar resumo
    detected_classes_counts = Counter()

    print(f"\n--- Processando {len(final_refined_events)} eventos finais detectados ---")
    event_counter_id = 0
    for event in final_refined_events:
        final_predicted_class_name = class_names[event['prediction_id']]
        event_start_sample = event['start_sample']
        event_end_sample = event['end_sample']

        # Pega o áudio correspondente ao evento REFINADO
        event_audio_data = y_long[event_start_sample:event_end_sample]

        # Evita salvar arquivos vazios se por algum motivo o segmento for inválido
        if len(event_audio_data) == 0:
            continue

        detected_classes_counts[final_predicted_class_name] += 1

        # Salva o recorte apenas se não for silêncio OU se SALVAR_RECORTE_SILENCIO for True
        if save_silent_segments or final_predicted_class_name != "Silêncio":
            event_counter_id += 1
            event_start_time = event_start_sample / sr
            event_end_time = event_end_sample / sr

            output_filename = f"{final_predicted_class_name}_{int(event_start_time)}-{int(event_end_time)}s_event_{event_counter_id}.wav"
            if final_predicted_class_name == "Silêncio" and save_silent_segments:
                output_filename = f"SILENCE_{int(event_start_time)}-{int(event_end_time)}s_event_{event_counter_id}.wav"

            output_filepath = os.path.join(output_folder, output_filename)

            try:
                sf.write(output_filepath, event_audio_data, sr)
            except Exception as e:
                print(f"  ❌ ERRO ao salvar recorte agrupado '{output_filename}': {e}")

    # 3.8. Mostrar resultados finais
    print("\n=== RESUMO FINAL DE EVENTOS DETECTADOS ===")
    if not detected_classes_counts:
        print("Nenhum evento detectado neste áudio.")
    else:
        for class_name_in_order in class_names:
            count = detected_classes_counts.get(class_name_in_order, 0)
            print(f"- {class_name_in_order}: {count} ocorrência(s)")

        print(f"\nOs recortes de áudio de eventos refinados foram salvos na pasta: '{output_folder}'")
        if not save_silent_segments:
            print(
                "  (Apenas recortes de eventos não-Silêncio foram salvos. Para incluir 'Silêncio', configure 'SALVAR_RECORTE_SILENCIO = True'.)")
        else:
            print("  (Recortes de 'Silêncio' foram incluídos no salvamento.)")


# === 4. EXECUÇÃO PRINCIPAL ===
if __name__ == "__main__":
    try:
        modelo_final = joblib.load("modelo_xgb_sono_final.pkl")
        scaler_final = joblib.load("scaler_xgb_sono_final.pkl")
        print("✅ Modelo final e Scaler carregados com sucesso.")
    except FileNotFoundError:
        print("❌ ERRO: 'modelo_xgb_sono_final.pkl' ou 'scaler_xgb_sono_final.pkl' não encontrados.")
        print("Certifique-se de que o script de fine-tuning foi executado e salvou esses arquivos.")
        exit()
    except Exception as e:
        print(f"❌ Erro ao carregar modelo/scaler: {e}")
        exit()

    predict_and_segment(
        audio_path=CAMINHO_AUDIO_LONGO,
        model=modelo_final,
        scaler=scaler_final,
        sr_target=SR_ALVO,
        segment_duration_seconds=DURACAO_SEGMENTO_SEGUNDOS,
        overlap_percentage=OVERLAP_PERCENTAGE,
        output_folder=PASTA_SAIDA_RECORTES,
        class_names=NOMES_CLASSES,
        save_silent_segments=SALVAR_RECORTE_SILENCIO,
        max_event_duration_seconds=MAX_EVENT_DURATION_SECONDS,
        timeline_resolution_seconds=TIMELINE_RESOLUTION_SECONDS  # Novo parâmetro
    )
